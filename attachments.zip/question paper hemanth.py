import pandas as pd
import random
import sys
c=[]
d=[]
ans=[]
e=[]
enans=[]
orans=[]
i=0
df=pd.read_csv('CurrencyData File.csv',delimiter=',')
questions=[list(row) for row in df.values]
while i< 301:
    c.append(i)
    i+=1
c.pop(0)
h=int(input("enter your roll no:"))

q=random.sample(c,1)
print("your are assigned Question paper :",q)
d=random.sample(c,5)
for j in range(0,5):
    for i in range(0,300):
        if d[j]==questions[i][0]:
            print(j+1,"What is the symbol of" ,questions[i][1])
            ans=random.sample(c,3)
            for l in range(0,3):
                e.append(questions[ans[l]-1][2])
            e.append(questions[i][2])
            random.shuffle(e)
            print("a.",e[0],"\t","b.",e[1],"\t","c.",e[2],"\t","d.",e[3])
            e.clear()
            m=input("Enter your Answer not option:")
            enans.append(m)
            orans.append(questions[i][2])
        elif  d[j]==questions[i][0]:
            print(j+1,"What is the full form of" ,questions[i][2])
            ans=random.sample(c,3)
            for l in range(0,3):
                e.append(questions[ans[l]-1][1])
            e.append(questions[i][1])
            random.shuffle(e)
            print("a.",e[0],"\t","b.",e[1],"\t","c.",e[2],"\t","d.",e[3])
            e.clear()
            enans.append(m)
            orans.append(questions[i][1])
print("your Answers","     ",'Key')
for i in range(0,5):
    print('  ',enans[i],"          ",' ',orans[i])
p=0
for i in range(0,5):
    if enans[i]==orans[i]:
        p+=1
print("your score is ",p,"out of",5)
print("\n")    















                
